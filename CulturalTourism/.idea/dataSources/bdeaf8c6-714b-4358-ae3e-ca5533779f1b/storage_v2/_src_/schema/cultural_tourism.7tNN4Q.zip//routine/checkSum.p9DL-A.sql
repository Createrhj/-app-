create
    definer = root@localhost procedure checkSum(IN userID int, IN goodsID int, IN isCheck int, OUT result int,
                                                OUT total int)
BEGIN
    -- 定义错误码
    DECLARE error INTEGER DEFAULT 0;
    -- 当出现异常时错误码赋1
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET error=1;
    start transaction ;
    /*确认*/
    update cart set is_check=isCheck where user_id=userID and goods_id=goodsID;
    /*查看购物车总额*/
    select SUM(goods_price*goods_number) into total from goods,cart,user
    where goods.goods_id=cart.goods_id
      and cart.user_id=user.user_id
      and cart.user_id=userID
      and is_check=1;
    IF error = 1 THEN
        ROLLBACK;
        set result = 1;
    ELSE
        COMMIT;
        set result = 0;
    END IF;
end;

