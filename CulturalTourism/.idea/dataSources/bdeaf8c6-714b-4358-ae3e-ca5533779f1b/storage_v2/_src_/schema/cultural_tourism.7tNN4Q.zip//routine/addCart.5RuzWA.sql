create
    definer = root@localhost procedure addCart(IN userID int, IN goodsID int, IN goodsNumber int, OUT result int)
BEGIN
    DECLARE haveGoods int default 0;
    -- 定义错误码
    DECLARE t_error INTEGER DEFAULT 0;
    -- 当出现异常时错误码赋1
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SET t_error=1;
    -- 是否存在该商品
    start transaction ;
    select count(*) into haveGoods from cart where user_id=userID and goods_id=goodsID;
    IF haveGoods!=0 THEN
        update cart set goods_number=goods_number+goodsNumber where  goods_id=goodsID and user_id=userID;
    ELSE
        insert into cart set user_id=userID,goods_id=goodsID,goods_number=goodsNumber,is_check=0;
    END IF;

    IF t_error = 1 THEN
        ROLLBACK;
        set result = 1;
    ELSE
        commit;
        set result=0;
    END IF;

end;

