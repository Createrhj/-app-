create
    definer = root@localhost procedure deleteOrders(IN ordersID bigint, OUT result int)
BEGIN
    -- 定义错误码
    DECLARE error INTEGER DEFAULT 0;
    -- 当出现异常时错误码赋1
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET error=1;
    -- 开启事务
    start TRANSACTION;
    delete from orders where orders_id=ordersID;
    delete from orders_items where orders_id=ordersID;
    -- 如果出现异常回滚事务，否则提交事务
    IF error = 1 THEN
        ROLLBACK;
        set result = 1;
    ELSE
        COMMIT;
        set result = 0;
    END IF;
end;

